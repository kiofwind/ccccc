#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include <xmmintrin.h>

const float G[4][3] = {
    {1.0, 0.0, 0.0}, {0.5, 0.5, 0.5}, {0.5, -0.5, 0.5}, {0.0, 0.0, 1.0}};
const float G_T[3][4] = {
    {1, 0.5, 0.5, 0.0}, {0.0, 0.5, -0.5, 0.0}, {0.0, 0.5, 0.5, 1.0}};
const float B[4][4] = {
    {1, 0, 0, 0}, {0, 1, -1, 1}, {-1, 1, 1, 0}, {0, 0, 0, -1}};
const float B_T[4][4] = {
    {1, 0, -1, 0}, {0, 1, 1, 0}, {0, -1, 1, 0}, {0, 1, 0, -1}};
const float A[4][2] = {{1, 0}, {1, 1}, {1, -1}, {0, -1}};
const float A_T[2][4] = {{1, 1, 1, 0}, {0, 1, -1, -1}};

// Matrix Multiplication: Out = A x B (A:M*K, B:K*N, out: M*N)
// All arrays should have their memory prepared correctly outside this function
// For rookies: this sgemm is the worst sgemm I've ever written throughout my
// career.
//      If you don't know where to start, optimize this function as a good
//      starting point.

inline void kernel8X8(const float * A, float * B, float * out, int K, int M, int N);
inline void kernelS8X16(const float * A, float * B, float * out, int K, int M, int N);
void sgemmpack(const float *A, const float *B, float *out, const int M, const int K,
           const int N){
    for (int i = 0; i < M*N; i++){
        out[i] = 0.0f;
    }
    int M_len = 8;
    int N_len = 16;
    float * Pack_B = (float*)malloc(sizeof(float)*N_len*K);
    for(int i = 0; i < M; i+=M_len){
        for(int j = 0; j < N; j+=N_len){
            for(int s = 0; s < N_len; s++){
                for(int p = 0; p < K;p++){
                    Pack_B[p*N_len+s] = B[p*N+s+j];
                }
            }
            // printf("1\n");
            kernel8X8(A+i*K,Pack_B,out+i*N+j,K,M,N);
        }
    }
    free(Pack_B);
}

void sgemm4(const float *A, const float *B, float *out, const int M, const int K, const int N){
  for (int i = 0; i < M * N; ++i) {
    out[i] = 0.0f;
  }
  __m256 t00, t10, t20, t30, t40, t50, t60, t70;
  t00 = t10 = t20 = t30 = t40 = t50 = t60 = t70 = _mm256_setzero_ps();
  __m256 a0, a1, a2, a3, a4, a5, a6, a7;
  __m256 b0;
  float * Pack_B = (float*)malloc(sizeof(float)*8*K);
  for(int i = 0; i < M; i += 8){
    for(int j = 0; j < N; j += 8){
      for(int s = 0; s < 8; s++){
        for(int p = 0; p < K; p++){
          Pack_B[p*8+s] = B[p*N+s+j];
        }
      }
      t00 = t10 = t20 = t30 = t40 = t50 = t60 = t70 = _mm256_setzero_ps();
      for(int k = 0; k < K; k++){
        a0 = _mm256_set1_ps(A[k+i*K]);
        a1 = _mm256_set1_ps(A[k+K+i*K]);
        a2 = _mm256_set1_ps(A[k+K*2+i*K]);
        a3 = _mm256_set1_ps(A[k+K*3+i*K]);
        a4 = _mm256_set1_ps(A[k+K*4+i*K]);
        a5 = _mm256_set1_ps(A[k+K*5+i*K]);
        a6 = _mm256_set1_ps(A[k+K*6+i*K]);
        a7 = _mm256_set1_ps(A[k+K*7+i*K]);
        b0 = _mm256_load_ps(Pack_B+k*8);
        t00 += a0*b0;
        t10 += a1*b0;
        t20 += a2*b0;
        t30 += a3*b0;
        t40 += a4*b0;
        t50 += a5*b0;
        t60 += a6*b0;
        t70 += a7*b0;
      }
      // printf("***\n");
      _mm256_store_ps(out+i*N+j,t00);
      _mm256_store_ps(out+i*N+j+N,t10);
      _mm256_store_ps(out+i*N+j+N*2,t20);
      _mm256_store_ps(out+i*N+j+N*3,t30);
      _mm256_store_ps(out+i*N+j+N*4,t40);
      _mm256_store_ps(out+i*N+j+N*5,t50);
      _mm256_store_ps(out+i*N+j+N*6,t60);
      _mm256_store_ps(out+i*N+j+N*7,t70);
    }
  }
  free(Pack_B);
}

inline void kernel8X8(const float * A, float * B, float * out, int K, int M, int N){
    //__m256 t00,t01,t02,t03,t10,t11,t12,t13,t20,t21,t22,t23,t30,t31,t32,t33;
    //t00 = t01 = t02 = t03 = t10 = t11 = t12 = t13 = t20 = t21 = t22 = t23 = t30 = t31 = t32 = t33 = _mm256_setzero_ps();
    int N_len = 16;
    __m256 t00, t10, t20, t30, t40, t50, t60, t70;
    t00 = t10 = t20 = t30 = t40 = t50 = t60 = t70 = _mm256_setzero_ps();
    __m256 t01, t11, t21, t31, t41, t51, t61, t71;
    t01 = t11 = t21 = t31 = t41 = t51 = t61 = t71 = _mm256_setzero_ps();
    __m256 a0, a1, a2, a3, a4, a5, a6, a7;
    __m256 b0, b1, b2, b3;
    for(int i = 0; i < K; i++){
        a0 = _mm256_set1_ps(A[i]);
        a1 = _mm256_set1_ps(A[i+K]);
        a2 = _mm256_set1_ps(A[i+K*2]);
        a3 = _mm256_set1_ps(A[i+K*3]);
        a4 = _mm256_set1_ps(A[i+K*4]);
        a5 = _mm256_set1_ps(A[i+K*5]);
        a6 = _mm256_set1_ps(A[i+K*6]);
        a7 = _mm256_set1_ps(A[i+K*7]);
        b0 = _mm256_load_ps(B+i*N_len);
        b1 = _mm256_load_ps(B+i*N_len+8);
        t00 += a0*b0;
        t10 += a1*b0;
        t20 += a2*b0;
        t30 += a3*b0;
        t40 += a4*b0;
        t50 += a5*b0;
        t60 += a6*b0;
        t70 += a7*b0;
        t01 += a0*b1;
        t11 += a1*b1;
        t21 += a2*b1;
        t31 += a3*b1;
        t41 += a4*b1;
        t51 += a5*b1;
        t61 += a6*b1;
        t71 += a7*b1;
    }
    _mm256_store_ps(out,t00);
    _mm256_store_ps(out+N,t10);
    _mm256_store_ps(out+N*2,t20);
    _mm256_store_ps(out+N*3,t30);
    _mm256_store_ps(out+N*4,t40);
    _mm256_store_ps(out+N*5,t50);
    _mm256_store_ps(out+N*6,t60);
    _mm256_store_ps(out+N*7,t70);
    _mm256_store_ps(out+8,t01);
    _mm256_store_ps(out+N+8,t11);
    _mm256_store_ps(out+N*2+8,t21);
    _mm256_store_ps(out+N*3+8,t31);
    _mm256_store_ps(out+N*4+8,t41);
    _mm256_store_ps(out+N*5+8,t51);
    _mm256_store_ps(out+N*6+8,t61);
    _mm256_store_ps(out+N*7+8,t71);
}

inline void sgemm(const float *A, const float *B, float *out, const int M, const int K,
           const int N) {
  for (int i = 0; i < M * N; ++i) {
    out[i] = 0.0f;
  }

  for (int i = 0; i < M; ++i)
    for (int k = 0; k < K; ++k)
      for (int j = 0; j < N; ++j)
          out[i * N + j]  += A[i * K + k] * B[k * N + j];
}

inline void sgemm1(const float *A, const float *B, float *out, const int M, const int K, const int N)
{
    for (int i = 0; i < M * N; ++i) {
        out[i] = 0.0f;
    }
    // int k_block_num = 2;  //or 1
    // int n_block_num = 256; //or  8,32
    int k_block_num = K/16;  //or 1
    int n_block_num = N/64; //or  8,32
    int k_bsize = K/k_block_num;
    int n_bsize = N/n_block_num;
    // printf("%d %d\n", k_bsize, n_bsize);
    // int k_bsize = 16;
    // int n_bsize = 144;
    // int k_block_num = K/k_bsize;
    // int n_block_num = N/n_bsize;
    int k_en = k_bsize*k_block_num;
    int n_en = n_bsize*n_block_num;
    int m_bsize = M;
    for(int kk = 0; kk<k_en; kk+=k_bsize){
        for(int nn = 0; nn<n_en; nn+=n_bsize){
            for(int m = 0; m<M; m++){
                for(int k=kk; k<kk+k_bsize&&k<K;k++){
                    for(int n = nn; n<nn+n_bsize&&n<N;n++){
                        out[m*N+n] += A[m*K+k]*B[k*N+n];
                    }
                }
            }
        }
    }
    // for(int mm = 0; mm < M; mm+=m_bsize){
    //   for(int kk = 0; kk<k_en; kk+=k_bsize)
    //     for(int nn = 0; nn<n_en; nn+=n_bsize){
    //         for(int m = mm; m<mm+m_bsize; m++){
    //             for(int k=kk; k<kk+k_bsize&&k<K;k++){
    //                 for(int n = nn; n<nn+n_bsize&&n<N;n++){
    //                     out[m*N+n] += A[m*K+k]*B[k*N+n];
    //                 }
    //             }
    //         }
    //     }
    // }
}

void sgemm3(const float *A, const float *B, float *out, const int M, const int K, const int N)
{
    for (int i = 0; i < M * N; ++i) {
        out[i] = 0.0f;
    }
    // int k_block_num = 2;  //or 1
    // int n_block_num = 256; //or  8,32
    int k_block_num = K/16;  //or 1
    int n_block_num = N/48; //or  8,32
    int k_bsize = K/k_block_num;
    int n_bsize = N/n_block_num;
    // printf("%d %d\n", k_bsize, n_bsize);
    // int k_bsize = 16;
    // int n_bsize = 144;
    // int k_block_num = K/k_bsize;
    // int n_block_num = N/n_bsize;
    int M_len = 8;
    int N_len = 16;
    int k_en = k_bsize*k_block_num;
    int n_en = n_bsize*n_block_num;
    __m256 t00, t10, t20, t30, t40, t50, t60, t70;
    t00 = t10 = t20 = t30 = t40 = t50 = t60 = t70 = _mm256_setzero_ps();
    __m256 t01, t11, t21, t31, t41, t51, t61, t71;
    t01 = t11 = t21 = t31 = t41 = t51 = t61 = t71 = _mm256_setzero_ps();
    __m256 tmp;
    __m256 a0, a1, a2, a3, a4, a5, a6, a7;
    __m256 b0, b1, b2, b3;
    float * Pack_B = (float *)malloc(sizeof(float)*k_bsize*N_len);
    for(int kk = 0; kk<k_en; kk+=k_bsize){
        for(int nn = 0; nn<n_en; nn+=n_bsize){
            for(int m = 0; m < M; m += M_len){
                for(int n = nn; n < nn+n_bsize; n += N_len){
                    // for(int s = 0; s < N_len; s++){
                    //   for(int p = 0; p < k_bsize; p++){
                    //     Pack_B[p*N_len+s] = B[(kk+p)*N+nn+s];
                    //   }
                    // }
                    t00 = t10 = t20 = t30 = t40 = t50 = t60 = t70 = _mm256_setzero_ps();
                    t01 = t11 = t21 = t31 = t41 = t51 = t61 = t71 = _mm256_setzero_ps();
                    for(int k = kk; k < kk+k_bsize; k++){
                      a0 = _mm256_set1_ps(A[m*K+k]);
                      a1 = _mm256_set1_ps(A[(m+1)*K+k]);
                      a2 = _mm256_set1_ps(A[(m+2)*K+k]);
                      a3 = _mm256_set1_ps(A[(m+3)*K+k]);
                      a4 = _mm256_set1_ps(A[(m+4)*K+k]);
                      a5 = _mm256_set1_ps(A[(m+5)*K+k]);
                      a6 = _mm256_set1_ps(A[(m+6)*K+k]);
                      a7 = _mm256_set1_ps(A[(m+7)*K+k]);
                      b0 = _mm256_load_ps(B+k*N+n);
                      b1 = _mm256_load_ps(B+k*N+n+8);
                      t00 += a0*b0;
                      t10 += a1*b0;
                      t20 += a2*b0;
                      t30 += a3*b0;
                      t40 += a4*b0;
                      t50 += a5*b0;
                      t60 += a6*b0;
                      t70 += a7*b0;
                      t01 += a0*b1;
                      t11 += a1*b1;
                      t21 += a2*b1;
                      t31 += a3*b1;
                      t41 += a4*b1;
                      t51 += a5*b1;
                      t61 += a6*b1;
                      t71 += a7*b1;
                    }
                    tmp = _mm256_load_ps(out+m*N+n);
                    t00 += tmp;
                    _mm256_store_ps(out+m*N+n,t00);

                    tmp = _mm256_load_ps(out+m*N+8+n);
                    t01 += tmp;
                    _mm256_store_ps(out+m*N+n+8,t01);

                    tmp = _mm256_load_ps(out+(m+1)*N+n);
                    t10 += tmp;
                    _mm256_store_ps(out+(m+1)*N+n,t10);

                    tmp = _mm256_load_ps(out+(m+1)*N+8+n);
                    t11 += tmp;
                    _mm256_store_ps(out+(m+1)*N+n+8,t11);

                    tmp = _mm256_load_ps(out+(m+2)*N+n);
                    t20 += tmp;
                    _mm256_store_ps(out+(m+2)*N+n,t20);

                    tmp = _mm256_load_ps(out+(m+2)*N+8+n);
                    t21 += tmp;
                    _mm256_store_ps(out+(m+2)*N+n+8,t21);

                    tmp = _mm256_load_ps(out+(m+3)*N+n);
                    t30 += tmp;
                    _mm256_store_ps(out+(m+3)*N+n,t30);

                    tmp = _mm256_load_ps(out+(m+3)*N+8+n);
                    t31 += tmp;
                    _mm256_store_ps(out+(m+3)*N+n+8,t31);

                    tmp = _mm256_load_ps(out+(m+4)*N+n);
                    t40 += tmp;
                    _mm256_store_ps(out+(m+4)*N+n,t40);

                    tmp = _mm256_load_ps(out+(m+4)*N+8+n);
                    t41 += tmp;
                    _mm256_store_ps(out+(m+4)*N+n+8,t41);

                    tmp = _mm256_load_ps(out+(m+5)*N+n);
                    t50 += tmp;
                    _mm256_store_ps(out+(m+5)*N+n,t50);

                    tmp = _mm256_load_ps(out+(m+5)*N+8+n);
                    t51 += tmp;
                    _mm256_store_ps(out+(m+5)*N+n+8,t51);

                    tmp = _mm256_load_ps(out+(m+6)*N+n);
                    t60 += tmp;
                    _mm256_store_ps(out+(m+6)*N+n,t60);

                    tmp = _mm256_load_ps(out+(m+6)*N+8+n);
                    t61 += tmp;
                    _mm256_store_ps(out+(m+6)*N+n+8,t61);

                    tmp = _mm256_load_ps(out+(m+7)*N+n);
                    t70 += tmp;
                    _mm256_store_ps(out+(m+7)*N+n,t70);

                    tmp = _mm256_load_ps(out+(m+7)*N+8+n);
                    t71 += tmp;
                    _mm256_store_ps(out+(m+7)*N+n+8,t71);
                }
            }
        }
    }
    free(Pack_B);
}

inline void kernelS8X16(const float * A, float * B, float * out, int K, int M, int N)
{
    int N_len = 16;
    __m256 t00, t10, t20, t30, t40, t50, t60, t70;
    t00 = t10 = t20 = t30 = t40 = t50 = t60 = t70 = _mm256_setzero_ps();
    __m256 t01, t11, t21, t31, t41, t51, t61, t71;
    t01 = t11 = t21 = t31 = t41 = t51 = t61 = t71 = _mm256_setzero_ps();
    __m256 a0, a1, a2, a3, a4, a5, a6, a7;
    __m256 b0, b1, b2, b3;
    for(int i = 0; i < K; i++){
        a0 = _mm256_set1_ps(A[i]);
        a1 = _mm256_set1_ps(A[i+K]);
        a2 = _mm256_set1_ps(A[i+K*2]);
        a3 = _mm256_set1_ps(A[i+K*3]);
        a4 = _mm256_set1_ps(A[i+K*4]);
        a5 = _mm256_set1_ps(A[i+K*5]);
        a6 = _mm256_set1_ps(A[i+K*6]);
        a7 = _mm256_set1_ps(A[i+K*7]);
        b0 = _mm256_load_ps(B+i*N_len);
        b1 = _mm256_load_ps(B+i*N_len+8);
        t00 += a0*b0;
        t10 += a1*b0;
        t20 += a2*b0;
        t30 += a3*b0;
        t40 += a4*b0;
        t50 += a5*b0;
        t60 += a6*b0;
        t70 += a7*b0;
        t01 += a0*b1;
        t11 += a1*b1;
        t21 += a2*b1;
        t31 += a3*b1;
        t41 += a4*b1;
        t51 += a5*b1;
        t61 += a6*b1;
        t71 += a7*b1;
    }
    _mm256_store_ps(out,t00);
    _mm256_store_ps(out+N,t10);
    _mm256_store_ps(out+N*2,t20);
    _mm256_store_ps(out+N*3,t30);
    _mm256_store_ps(out+N*4,t40);
    _mm256_store_ps(out+N*5,t50);
    _mm256_store_ps(out+N*6,t60);
    _mm256_store_ps(out+N*7,t70);
    _mm256_store_ps(out+8,t01);
    _mm256_store_ps(out+N+8,t11);
    _mm256_store_ps(out+N*2+8,t21);
    _mm256_store_ps(out+N*3+8,t31);
    _mm256_store_ps(out+N*4+8,t41);
    _mm256_store_ps(out+N*5+8,t51);
    _mm256_store_ps(out+N*6+8,t61);
    _mm256_store_ps(out+N*7+8,t71);
}

void sgemm444(const float *A, const float *B, float *out, const int M, const int K, const int N){
    // float * B_T = (float*)malloc(sizeof(float)*K*N);
    // for(int i = 0; i < K; i++){
    //   for(int j = 0; j < N; j++){
    //     B_T[j*K+i] = B[i*N+j];
    //   }
    // }
    for(int i = 0; i < 16; i++){
      out[i] = 0;
    }
    __m128 a,b,c;
    for(int i = 0; i< 4; i++){
      a = _mm_load_ps(A+i*4);
      for(int j = 0; j < 4; j++){
          b = _mm_load_ps(B+j*4);
          c = a * b;
          for(int p = 0; p < 4; p++){
            out[i*4+j] += c[p];
          }
      }
    }
}

void sgemm_4X4(const float *A, const float *B, float *out, const int M, const int K,
           const int N)
{
    for (int i = 0; i < M * N; ++i) {
      out[i] = 0.0f;
    }
    __m128 a0, a1, a2, a3;
    __m128 b0, b1, b2, b3;
    __m128 t0, t1, t2, t3;
    t0 = t1 = t2 = t3 = _mm_setzero_ps();
    for(int i = 0; i < K; i++){
      a0 = _mm_set1_ps(A[i]);
      a1 = _mm_set1_ps(A[i+K]);
      a2 = _mm_set1_ps(A[i+K*2]);
      a3 = _mm_set1_ps(A[i+K*3]);
      b0 = _mm_load_ps(B+i*N);
      t0 += a0*b0;
      t1 += a1*b0;
      t2 += a2*b0;
      t3 += a3*b0;
    }
    _mm_store_ps(out,t0);
    _mm_store_ps(out+4, t1);
    _mm_store_ps(out+8, t2);
    _mm_store_ps(out+12, t3);
}
// User API for winograd F(2,3)
// image: [batch * C * inHeight * inWidth]
// filter: [K * C * 3 * 3]
// result: [batch * K * outHeight * outWidth]
void winconv_2x3(float *__restrict__ image, const int inHeight,
                 const int inWidth, const int C, float *__restrict__ filter,
                 const int K, const int N, float *__restrict__ out,
                 float *__restrict__ U, float *__restrict__ V,
                 float *__restrict__ M) {
  // m = 2; r = 3; alpha = 4
  const int outHeight = inHeight - 2;
  const int outWidth = inWidth - 2;
  const int sizeI = inHeight * inWidth;
  const int sizeF = 3 * 3;
  const int sizeO = outHeight * outWidth;
  const int P = outHeight / 2 * outWidth / 2 * N;
  float tmp_u[12];  // 4 * 3
  float u[16];      // 4 * 4;


  // U[:, :, k, c] = G * filters[k, c, :, :] * G.T()
  float* filters_ptr = filter;
  for (int i = 0; i < K*C; ++i){
      sgemm(&G[0][0], filters_ptr, tmp_u, 4, 3, 3);
      sgemm_4X4(tmp_u, &G_T[0][0], u, 4, 3, 4);
      for (int j = 0; j < 16; ++j ){
          U[j*K*C+i] = u[j];
      }
      filters_ptr += sizeF;
  }

  // V[:, :, c, p] = B_T * image[c, b, :, :] * B
  float tmp_v[16];
  float d[16];  // d: [4 * 4];
  float v[16];  // v: [4 * 4];

  for (int n = 0; n < N; ++n)
    for (int c = 0; c < C; ++c) {
      for (int y = 0; y < outHeight / 2; ++y) {
        for (int x = 0; x < outWidth / 2; ++x) {
          // Generate d_cb
          for (int iy = 0; iy < 4; ++iy)
            for (int ix = 0; ix < 4; ++ix)
              d[iy * 4 + ix] = image[(n * C + c) * sizeI +
                                     (y * 2 + iy) * inWidth + (x * 2 + ix)];
          sgemm_4X4(&B_T[0][0], d, tmp_v, 4, 4, 4);
          sgemm_4X4(tmp_v, &B[0][0], v, 4, 4, 4);
          int b = ((n * outHeight / 2) + y) * outWidth / 2 + x;
          for (int xi = 0; xi < 4; ++xi)
            for (int nu = 0; nu < 4; ++nu)
              V[((xi * 4 + nu) * C + c) * P + b] = v[xi * 4 + nu];
        }
      }
    }

  // M[xi, nu, :, :] = U[xi, nu, :, :] * V[xi, nu, :, :]
  float *M_ptr = M;
  float *U_ptr = U;
  float *V_ptr = V;
  for (int i = 0; i < 16; ++i){
      if(P>10000){
          sgemm3(U_ptr, V_ptr, M_ptr, K, C, P);
      }
      else{
          sgemm(U_ptr, V_ptr, M_ptr, K, C, P);
      }
      // sgemm(U_ptr, V_ptr, M_ptr, K, C, P);
      M_ptr += K*P;
      U_ptr += K*C;
      V_ptr += C*P;
  }

  // Y = A_T * m * A
  float mm[16];       // 4 * 4
  float temp_out[4];  // 2 * 2
  float tmp_m[8];     // 2 * 4

  for (int n = 0; n < N; ++n)
    for (int k = 0; k < K; ++k) {
      for (int y = 0; y < outHeight / 2; ++y) {
        for (int x = 0; x < outWidth / 2; ++x) {
          int b = (n * outHeight / 2 + y) * outWidth / 2 + x;
          for (int xi = 0; xi < 4; ++xi) {
            for (int nu = 0; nu < 4; ++nu) {
              mm[xi * 4 + nu] = M[((xi * 4 + nu) * K + k) * P + b];
            }
          }
          sgemm(&A_T[0][0], mm, tmp_m, 2, 4, 4);
          sgemm(tmp_m, &A[0][0], temp_out, 2, 4, 2);
          for (int i = 0; i < 2; ++i)
            for (int j = 0; j < 2; ++j)
              out[((n * K + k) * outHeight + y * 2 + i) * outWidth + x * 2 +
                  j] = temp_out[i * 2 + j];
        }
      }
    }
}